const fizzBuzz = () => {
    for (let i = 0; i < 51; i++) {
        if (i % 3 === 0 && i % 5 === 0) {
            console.log('fizzbuzz');
        }
         else if (i % 3 === 0) {
            console.log('fizz');
        } else if (i % 5 === 0) {
            console.log('buzz');
        } else {
            console.log(i);
        }
    }
};
// TEST
fizzBuzz();


const getMax = (num1, num2) => {
    return num1 > num2 ? num1 : num2;
};
// TEST
let num1 = 10;
let num2 = 5;
console.log(`Le plus grand nombre entre ${num1} et ${num2} est ${getMax(num1,num2)}`);


const guessNumber = () => {
    let randomNumber = Math.floor(Math.random() * (50 - 10 + 1) + 10);
    let answer = window.prompt('Devinez le nombre entre 10 et 50');
    while (parseInt(answer) !== randomNumber) {
        if (parseInt(answer) < randomNumber) {
            answer = window.prompt('C\'est plus ! Essayez encore');
        } else {
            answer = window.prompt('C\'est moins ! Essayez encore');
        }
    }
    window.alert('Félicitations')
};
// TEST
// guessNumber(); // flemme des popups


const palindrome = word => {
    // return word.slice(0, word.length/2) === word.slice(word.length/2, word.length-1).split().reverse().join();
    let firstSlice = word.length % 2 === 0 ? word.slice(0, word.length/2) : word.slice(0, word.length/2 + 1);
    let secondSlice = word.slice(word.length/2, word.length).split('').reverse().join('');
    return firstSlice === secondSlice;
};
// TEST
let word = 'kayak';
console.log(`est-ce que ${word} est un palindrome ? ${palindrome(word) ? 'oui' : 'non'}`);

const capitalizeWords = sen => {
    // const arr = sen.toLowerCase().split(' ');
    // for (let i = 0; i < arr.length; i++) {
    //     arr[i] = arr[i].charAt(0).toUpperCase() + arr[i].slice(1);

    // }
    // const str2 = arr.join(' ');
    // return str2;
    return sen.toLowerCase().split(' ').map(item => item.charAt(0).toUpperCase() + item.slice(1)).join(' ');
};
// TEST
let sen = 'je vEuX GaGneR aU lOtO';
console.log(`Modif de la phrase '${sen}' : '${capitalizeWords(sen)}'`);